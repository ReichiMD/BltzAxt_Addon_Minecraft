---
title: Blocks
categories:
    - title: General
      color: blue
    - title: Visuals
      color: purple
    - title: Tutorials
      color: green
    - title: Vanilla Re-Creations
      color: orange
    - title: Documentation
      color: red
---
