---
title: Download Example Packs
category: Extra
description: Appendix for downloading example Packs
prefix: "b. "
nav_order: 2
show_outline: false
mentions:
    - SirLich
    - Joelant05
    - Dreamedc2015
    - sermah
    - SmokeyStack
    - MedicalJewel105
    - Lufurrius
    - TheDoctor15
    - TheItsNameless
    - QuazChick
---

::: tip
This is an appendix page. You can start the guide from the beginning [here](/guide/introduction).
:::

To get the most out of the guide, you should always attempt all guide-exercises yourself! However if you get very stuck, the example packs should give you some valuable reference material.

Download here:

<Button link="https://github.com/Bedrock-OSS/bedrock-examples/releases/download/download/guide.mcaddon">
    Download Add-On
</Button>

To install, simply unzip the behavior pack into the Minecraft folder: `com.mojang\development_behavior_packs` or `com.mojang\development_*_packs`, depending on which pack you downloaded.
