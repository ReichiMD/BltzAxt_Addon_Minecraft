---
title: Introduction to Entity Visuals
nav_order: 1
tags:
    - guide
category: General
mentions:
    - SirLich
    - MedicalJewel105
    - Overload1252
description: Introduction to Entity Visuals.
---

## What is this section about?

Welcome, stranger. You have entered entity visuals section.
Here you can learn how to improve visual part of your content. This section is important as good expression is mostly formed of how everything looks in add-on.