---
title: Text & Localization
categories:
    - title: General
      color: blue
    - title: Emojis & Symbols
      color: green
---
