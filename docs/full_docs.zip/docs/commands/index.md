---
title: Commands
categories:
    - title: General
      color: green
    - title: Commands
      color: green
    - title: On Event Systems
      color: blue
    - title: Scoreboard Systems
      color: blue
    - title: Techniques
      color: orange
    - title: Useful Creations
      color: yellow
---
