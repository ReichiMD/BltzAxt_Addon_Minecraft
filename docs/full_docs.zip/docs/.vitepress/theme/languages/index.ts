import json from "./json";
import lang from "./lang";
import molang from "./molang";

export default [json, lang, molang];
