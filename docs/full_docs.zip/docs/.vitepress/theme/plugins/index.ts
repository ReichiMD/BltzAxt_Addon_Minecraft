import taskListsPlugin from "markdown-it-task-lists";
import { inlineHighlightPlugin } from "./inlineHighlight";

export default [inlineHighlightPlugin, taskListsPlugin];
