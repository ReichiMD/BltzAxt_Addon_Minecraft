import { ThemeConfig } from "../types";
import { useData } from "vitepress";

export default useData<ThemeConfig>;
