<template>
  <svg
    class="frame-corner"
    xmlns="http://www.w3.org/2000/svg"
    width="11"
    height="11"
    viewBox="0 0 11 11"
    fill="var(--light-bg-color)"
    stroke="var(--border-color)"
  >
    <path d="M 0,0 V 11 A 11,11 0 0 1 11,0 Z" style="stroke-width: 2; paint-order: stroke fill" />
  </svg>
</template>
